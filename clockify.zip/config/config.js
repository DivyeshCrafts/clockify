module.exports = {
    DEFAULT_CONFIG: {
    DB_USERNAME: "",
    DB_PASSWORD: "",
    DB_HOST: "127.0.0.1",
    DB_NAME: "my_clockify",
    DB_PORT: 27017,
}}